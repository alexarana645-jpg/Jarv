package com.example.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Original animated "HUD" background inspired by generic sci-fi
 * interface aesthetics: concentric rings, a radar sweep, tick marks,
 * corner brackets, and orbiting nodes. Pure Canvas drawing, no assets.
 */
class HudView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val cyan = Color.parseColor("#4DE8FF")
    private val cyanDim = Color.parseColor("#1E6E80")
    private val cyanFaint = Color.parseColor("#123340")

    private var slowAngle = 0f   // outer ring, rotates clockwise, slow
    private var fastAngle = 0f   // inner ring, rotates counter-clockwise, faster
    private var sweepAngle = 0f  // radar sweep
    private var pulse = 0f       // 0..1 pulsing center glow

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = cyanDim
    }
    private val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = cyan
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = cyan
    }
    private val bracketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = cyan
        strokeCap = Paint.Cap.ROUND
    }
    private val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = cyan
        alpha = 160
    }

    init {
        ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 14000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { slowAngle = it.animatedValue as Float; invalidate() }
            start()
        }
        ValueAnimator.ofFloat(360f, 0f).apply {
            duration = 8000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { fastAngle = it.animatedValue as Float }
            start()
        }
        ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 3000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { sweepAngle = it.animatedValue as Float }
            start()
        }
        ValueAnimator.ofFloat(0f, 1f, 0f).apply {
            duration = 2200
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { pulse = it.animatedValue as Float }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = min(width, height) * 0.30f

        drawCornerBrackets(canvas)
        drawOuterTicks(canvas, cx, cy, radius * 1.55f)
        drawRing(canvas, cx, cy, radius * 1.4f, slowAngle, segmented = true)
        drawRing(canvas, cx, cy, radius * 1.1f, fastAngle, segmented = false)
        drawRadarSweep(canvas, cx, cy, radius * 0.85f)
        drawCenter(canvas, cx, cy, radius * 0.35f)
    }

    private fun drawCornerBrackets(canvas: Canvas) {
        val len = width * 0.05f
        val margin = width * 0.04f
        val corners = listOf(
            Triple(margin, margin, 1),
            Triple(width - margin, margin, 2),
            Triple(margin, height - margin, 3),
            Triple(width - margin, height - margin, 4)
        )
        for ((x, y, quadrant) in corners) {
            val dx = if (quadrant == 1 || quadrant == 3) 1 else -1
            val dy = if (quadrant == 1 || quadrant == 2) 1 else -1
            canvas.drawLine(x, y, x + len * dx, y, bracketPaint)
            canvas.drawLine(x, y, x, y + len * dy, bracketPaint)
        }
    }

    private fun drawOuterTicks(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        for (i in 0 until 60) {
            val angle = Math.toRadians((i * 6).toDouble())
            val inner = if (i % 5 == 0) radius - 18f else radius - 8f
            val x1 = cx + (inner * cos(angle)).toFloat()
            val y1 = cy + (inner * sin(angle)).toFloat()
            val x2 = cx + (radius * cos(angle)).toFloat()
            val y2 = cy + (radius * sin(angle)).toFloat()
            tickPaint.alpha = if (i % 5 == 0) 220 else 90
            canvas.drawLine(x1, y1, x2, y2, tickPaint)
        }
    }

    private fun drawRing(canvas: Canvas, cx: Float, cy: Float, radius: Float, rotation: Float, segmented: Boolean) {
        val rect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        canvas.drawCircle(cx, cy, radius, ringPaint)
        if (segmented) {
            val segments = 8
            val gap = 10f
            val sweep = (360f / segments) - gap
            for (i in 0 until segments) {
                val start = rotation + i * (360f / segments)
                canvas.drawArc(rect, start, sweep, false, tickPaint)
            }
        } else {
            canvas.save()
            canvas.rotate(rotation, cx, cy)
            canvas.drawArc(rect, 0f, 100f, false, tickPaint)
            canvas.drawArc(rect, 160f, 60f, false, tickPaint)
            canvas.drawArc(rect, 260f, 40f, false, tickPaint)
            canvas.restore()
        }
    }

    private fun drawRadarSweep(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        canvas.drawCircle(cx, cy, radius, ringPaint)
        val angle = Math.toRadians(sweepAngle.toDouble())
        val x = cx + (radius * cos(angle)).toFloat()
        val y = cy + (radius * sin(angle)).toFloat()
        canvas.drawLine(cx, cy, x, y, sweepPaint)
    }

    private fun drawCenter(canvas: Canvas, cx: Float, cy: Float, radius: Float) {
        ringPaint.alpha = 255
        canvas.drawCircle(cx, cy, radius, ringPaint)
        glowPaint.alpha = (60 + pulse * 100).toInt()
        canvas.drawCircle(cx, cy, radius * (0.55f + pulse * 0.15f), glowPaint)
        glowPaint.alpha = 255
        canvas.drawCircle(cx, cy, radius * 0.12f, glowPaint)
    }
}
