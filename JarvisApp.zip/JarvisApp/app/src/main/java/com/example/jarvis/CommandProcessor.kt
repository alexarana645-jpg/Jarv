package com.example.jarvis

import android.content.Context
import android.content.Intent
import android.text.format.DateFormat
import java.util.Date
import java.util.Locale

/**
 * Turns a heard command string into an action and a spoken reply.
 * Extend this class to add new command types (timers, texting, web search, etc).
 */
class CommandProcessor(private val context: Context) {

    fun process(command: String): String {
        val text = command.lowercase(Locale.US).trim()

        return when {
            text.startsWith("open ") -> openApp(text.removePrefix("open ").trim())
            text.startsWith("launch ") -> openApp(text.removePrefix("launch ").trim())
            text.contains("what time") || text.contains("what's the time") ->
                "It's ${DateFormat.format("h:mm a", Date())}"
            text.contains("search for") -> webSearch(text.substringAfter("search for").trim())
            text.contains("call ") -> "I don't have permission to make calls yet, but you can add that."
            else -> "I heard \"$command\" but I don't know that command yet."
        }
    }

    private fun openApp(spokenName: String): String {
        if (spokenName.isEmpty()) return "Which app would you like to open?"

        val pm = context.packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }

        val match = apps
            .map { it to pm.getApplicationLabel(it).toString() }
            .minByOrNull { levenshtein(it.second.lowercase(Locale.US), spokenName) }

        return if (match != null && levenshtein(match.second.lowercase(Locale.US), spokenName) <= 4) {
            val launchIntent = pm.getLaunchIntentForPackage(match.first.packageName)
            launchIntent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            launchIntent?.let { context.startActivity(it) }
            "Opening ${match.second}"
        } else {
            "I couldn't find an app called $spokenName"
        }
    }

    private fun webSearch(query: String): String {
        if (query.isEmpty()) return "What would you like me to search for?"
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Searching for $query"
        } catch (e: Exception) {
            "I couldn't open a search for $query"
        }
    }

    // Simple edit-distance so "open spotify" matches "Spotify" even with
    // small mis-hearings from the speech recognizer.
    private fun levenshtein(a: String, b: String): Int {
        val dp = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) dp[i][0] = i
        for (j in 0..b.length) dp[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                dp[i][j] = if (a[i - 1] == b[j - 1]) {
                    dp[i - 1][j - 1]
                } else {
                    1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
                }
            }
        }
        return dp[a.length][b.length]
    }
}
